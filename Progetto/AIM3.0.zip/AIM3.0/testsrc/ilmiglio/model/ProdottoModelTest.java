package ilmiglio.model;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Date;
import java.sql.SQLException;
import java.util.Collection;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class ProdottoModelTest {

	private static ProdottoModel classUnderTest;
	private static ProdottoBean bean;
	private static int codice;

	/**
	 * Setta classe undertest e bean prima del testretrievebykey
	 * 
	 * @throws Exception
	 */
	@BeforeAll
	static void setUp() throws Exception {

		classUnderTest = new ProdottoModel();
		codice = 11111;

		assertNotNull(classUnderTest);

	}

	/**
	 * Testa il metodo doRetieveByKey con un prodotto presente nel DB
	 * 
	 * @throws Exception
	 */
	@Test
	void testDoRetrieveByKeyProdottoInDB() throws Exception {

		System.out.println("- doRetrieveByKey -");
		bean = classUnderTest.doRetrieveByKey(codice);
		assertNotNull(bean);
		assertEquals(codice, bean.getCodice());

	}

	/**
	 * Testa il metodo doRetrieveByKey con prodotto non presente in DB
	 * 
	 * @throws Exception
	 */
	@Test
	void testDoRetrieveByKeyNonInDB() throws Exception {

		System.out.println("- doRetrieveByKey -");
		bean = classUnderTest.doRetrieveByKey(99999);
		assertNull(bean);

	}

	/**
	 * Testa il metodo retrieveAll con i prodotti presenti nel DB
	 * 
	 * @throws Exception
	 */
	@Test
	void testDoRetrieveAll() throws Exception {

		System.out.println("- doRetrieveAll -");

		String str;

		str = "2012-02-02";
		Date datProd = Date.valueOf(str);
		str = "2025-02-02";
		Date datScad = Date.valueOf(str);

		bean = new ProdottoBean();
		bean.setCodice(77777);
		bean.setNome_tipo("Prova");
		bean.setQuantit�_disponibile(25);
		bean.setData_produzione(datProd);
		bean.setData_scadenza(datScad);
		bean.setPrezzo(25);
		classUnderTest.insert(bean);

		Collection<ProdottoBean> collection = (Collection<ProdottoBean>) classUnderTest.doRetrieveAll();
		assertNotEquals(0, collection.size());

		int cod = 0;
		for (ProdottoBean temp : collection) {
			cod = temp.getCodice();
		}
		classUnderTest.doDelete(bean.getCodice());
		System.out.println(cod);

	}

	/**
	 * Testa l'insert di un prodotto non in DB
	 * 
	 * @throws Exception
	 */
	@Test
	void testInsertNonInDB() throws Exception {

		System.out.println("- Insert -");

		String str;
		str = "2012-02-02";
		Date datProd = Date.valueOf(str);
		str = "2025-02-02";
		Date datScad = Date.valueOf(str);

		bean = new ProdottoBean();
		bean.setCodice(22222);
		bean.setData_produzione(datProd);
		bean.setData_scadenza(datScad);
		bean.setNome_tipo("Prova Test");
		bean.setPrezzo(10);
		bean.setQuantit�_disponibile(200);
		classUnderTest.doDelete(bean.getCodice());
		classUnderTest.insert(bean);
		ProdottoBean result = classUnderTest.doRetrieveByKey(bean.getCodice());
		classUnderTest.doDelete(bean.getCodice());
		assertNotNull(result);
		assertEquals(bean.getCodice(), result.getCodice());

	}

	/**
	 * Testa l'insert di un prodotto in DB
	 * 
	 * @throws Exception
	 */
	@Test
	void testInsertInDB() throws Exception {

		System.out.println("- Insert -");

		String str;
		str = "2019-02-05";
		Date datProd = Date.valueOf(str);
		str = "2019-02-28";
		Date datScad = Date.valueOf(str);

		bean = new ProdottoBean();
		bean.setCodice(11111);
		bean.setData_produzione(datProd);
		bean.setData_scadenza(datScad);
		bean.setNome_tipo("prova");
		bean.setPrezzo(20);
		bean.setQuantit�_disponibile(100);
		boolean exc = false;

		try {
			classUnderTest.insert(bean);
			exc = false;
		} catch (SQLException e) {
			exc = true;
		}

		assertTrue(exc);

	}

	/**
	 * Testa la delete di un prodotto
	 * 
	 * @throws Exception
	 */
	@Test
	void testDoDelete() throws Exception {

		System.out.println("- Delete -");

		String str;
		str = "2019-02-05";
		Date datProd = Date.valueOf(str);
		str = "2019-02-28";
		Date datScad = Date.valueOf(str);

		bean = new ProdottoBean();
		bean.setCodice(99999);
		bean.setData_produzione(datProd);
		bean.setData_scadenza(datScad);
		bean.setNome_tipo("prova");
		bean.setPrezzo(20);
		bean.setQuantit�_disponibile(100);

		classUnderTest.insert(bean);

		ProdottoBean result = classUnderTest.doRetrieveByKey(bean.getCodice());
		boolean exc;

		if (result.getCodice() == bean.getCodice()) {
			exc = true;
		} else
			exc = false;

		if (exc) {
			classUnderTest.doDelete(bean.getCodice());
		}

		assertTrue(exc);

	}

	/**
	 * Testa l'update della quantit�
	 * 
	 * @throws Exception
	 */
	@Test
	void testDoUpdateQuantita() throws Exception {

		System.out.println("- Update Quantit� -");

		bean = new ProdottoBean();
		bean.setCodice(codice);
		bean.setQuantit�_disponibile(121);

		boolean exc = false;
		try {
			classUnderTest.doUpdateQuantita(bean.getCodice(), bean.getQuantit�_disponibile());
			exc = true;
		} catch (SQLException e) {
			exc = false;
		}

		assertTrue(exc);

	}

	@Test
	void testUpdate() {

		System.out.println("- Update -");

		bean = new ProdottoBean();
		bean.setCodice(codice);
		bean.setNome_tipo("Prova Test");
		bean.setQuantit�_disponibile(121);
		bean.setPrezzo(50);

		boolean exc = false;
		try {
			classUnderTest.update(bean);
			exc = true;
		} catch (SQLException e) {
			exc = false;
		}

		assertTrue(exc);

	}

}
