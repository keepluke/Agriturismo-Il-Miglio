package ilmiglio.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class ESoggettoModelTest {

	private static ESoggettoModel classUnderTest;
	private static ESoggettoBean bean;
	private static int cod_scontrino;
	private static int cod_prodotto;

	@BeforeAll
	static void setUp() throws Exception {

		classUnderTest = new ESoggettoModel();
		cod_scontrino = 1;
		cod_prodotto = 11111;

		assertNotNull(classUnderTest);

	}

	@Test
	void testDoRetrieveByKeyInDB() throws Exception {

		System.out.println("- doRetrieveByKey -");

		bean = classUnderTest.doRetrieveByKey(cod_scontrino, cod_prodotto);
		assertNotNull(bean);
		assertEquals(cod_scontrino, bean.getCodice_scontrino());
		assertEquals(cod_prodotto, bean.getCodice_prodotto());

	}

	@Test
	void testDoRetrieveByKeyNonInDB() throws Exception {

		System.out.println("- doRetrieveByKey -");

		bean = classUnderTest.doRetrieveByKey(99999, 99999);
		assertNull(bean);

	}

}
