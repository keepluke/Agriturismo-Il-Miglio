package ilmiglio.model;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class ClienteModelTest {

	private static UtenteModel utenteModel;
	private static UtenteBean utenteBean;

	private static ClienteModel classUnderTest;
	private static ClienteBean bean;

	/**
	 * Setta classe undertest e bean prima del testretrievebykey
	 * 
	 * @throws Exception
	 */
	@BeforeAll
	static void setUp() throws Exception {

		classUnderTest = new ClienteModel();
		utenteModel = new UtenteModel();

		assertNotNull(classUnderTest);

	}

	/**
	 * Testa il metodo doRetieveByKey con un cliente presente nel DB
	 * 
	 * @throws Exception
	 */
	@Test
	void testDoRetrieveByKeyClienteInDB() throws Exception {

		System.out.println("- doRetrieveByKey -");
		
		UtenteBean uBean = new UtenteBean();
		UtenteModel uModel = new UtenteModel();
		
		uBean.setEmail("a@b.com");
		uBean.setPass("pass");
		uBean.setTipo("cliente");
		uModel.insert(uBean);
		
		bean = new ClienteBean();
		bean.setEmail_cliente(uBean.getEmail());
		bean.setNome_cliente("a");
		bean.setCognome_cliente("b");
		bean.setTelefono("123456789");
		bean.setIndirizzo("Via Roma");
		classUnderTest.insert(bean);
		
		ClienteBean result = classUnderTest.doRetrieveByKey(uBean.getEmail());
		
		classUnderTest.doDeleteByKey(uBean.getEmail());
		assertNotNull(result);
		assertEquals(uBean.getEmail(), result.getEmail_cliente());
		uModel.doDeleteByKey(uBean.getEmail());

	}

	/**
	 * Testa il metodo doRetrieveByKey con cliente non presente in DB
	 * 
	 * @throws Exception
	 */
	@Test
	void testDoRetrieveByKeyNonInDB() throws Exception {

		System.out.println("- doRetrieveByKey -");
		bean = classUnderTest.doRetrieveByKey("a@b.com");
		assertNull(bean);

	}

	/**
	 * Test del metodo insert non presente nel DB
	 * 
	 * @throws Exception
	 */
	@Test
	void testInsertClienteNonInDB() throws Exception {

		System.out.println("- Insert -");

		utenteBean = new UtenteBean();
		utenteBean.setEmail("pasquale@mail.com");
		utenteBean.setPass("password");
		utenteBean.setTipo("cliente");
		utenteModel.insert(utenteBean);

		bean = new ClienteBean();
		bean.setEmail_cliente("pasquale@mail.com");
		bean.setNome_cliente("luca");
		bean.setCognome_cliente("garelli");
		bean.setIndirizzo("Via Tasso 33 Salerno 84100");
		bean.setTelefono("3452304239");
		classUnderTest.doDeleteByKey(bean.getEmail_cliente());
		classUnderTest.insert(bean);
		ClienteBean result = classUnderTest.doRetrieveByKey("pasquale@mail.com");
		assertNotNull(result);
		classUnderTest.doDeleteByKey(utenteBean.getEmail());
		assertEquals("pasquale@mail.com", result.getEmail_cliente());
		utenteModel.doDeleteByKey(utenteBean.getEmail());
	}

	/**
	 * Test del metodo insert presente nel DB
	 * 
	 * @throws Exception
	 */
	@Test
	void testInsertUtenteInDB() throws Exception {

		System.out.println("- Insert -");
		utenteBean = new UtenteBean();
		utenteBean.setEmail("luca@mail.com");
		utenteBean.setPass("Laky1123#");
		utenteBean.setTipo("cliente");

		bean = new ClienteBean();
		bean.setEmail_cliente("luca@mail.com");
		bean.setNome_cliente("Luca");
		bean.setCognome_cliente("Garelli");
		bean.setIndirizzo("Via Tasso 33 Salerno 84100");
		bean.setTelefono("3452304239");
		boolean exc = false;
		try {
			utenteModel.insert(utenteBean);
			classUnderTest.insert(bean);
			utenteModel.insert(utenteBean);
			classUnderTest.insert(bean);
		} catch (SQLException e) {
			exc = true;
			classUnderTest.doDeleteByKey(bean.getEmail_cliente());
			utenteModel.doDeleteByKey(utenteBean.getEmail());
		}
		classUnderTest.doDeleteByKey(bean.getEmail_cliente());
		utenteModel.doDeleteByKey(utenteBean.getEmail());
		assertTrue(exc);

	}

	/**
	 * Test di Update cliente in DB
	 * 
	 * @throws Exception
	 */
	@Test
	void testUpdateClienteInDB() throws Exception {

		System.out.println("- Update -");
		
		utenteBean = new UtenteBean();
		utenteBean.setEmail("pasquale@mail.com");
		utenteBean.setPass("password");
		utenteBean.setTipo("cliente");
		utenteModel.insert(utenteBean);

		bean = new ClienteBean();
		bean.setEmail_cliente("pasquale@mail.com");
		bean.setNome_cliente("luca");
		bean.setCognome_cliente("garelli");
		bean.setIndirizzo("Via Tasso 33 Salerno 84100");
		bean.setTelefono("3452304239");
		classUnderTest.doDeleteByKey(bean.getEmail_cliente());
		classUnderTest.insert(bean);
		
		bean = new ClienteBean();
		bean.setEmail_cliente("pasquale@mail.com");
		bean.setIndirizzo("Via Tasso 33 Salerno 84121");
		bean.setTelefono("3452304239");
		boolean exc = false;
		try {
			classUnderTest.update(bean);
			exc = true;
		} catch (SQLException e) {
			exc = false;
		}
		classUnderTest.doDeleteByKey(utenteBean.getEmail());
		utenteModel.doDeleteByKey(utenteBean.getEmail());
		assertTrue(exc);

	}

	/**
	 * Test di Update cliente in DB
	 * 
	 * @throws Exception
	 */
	@Test
	void testUpdateClienteNonInDB() throws Exception {

		System.out.println("- Update -");
		bean = new ClienteBean();
		bean.setEmail_cliente("a@b.com");
		bean.setIndirizzo("Via Tasso 33 Salerno 8521");
		bean.setTelefono("3452304239");
		boolean exc = false;
		try {
			classUnderTest.update(bean);
			exc = true;
		} catch (SQLException e) {
			exc = false;
		}

		assertTrue(exc);

	}

}
