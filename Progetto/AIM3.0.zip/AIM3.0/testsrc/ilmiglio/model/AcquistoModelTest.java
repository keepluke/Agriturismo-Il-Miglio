package ilmiglio.model;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Date;
import java.util.ArrayList;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class AcquistoModelTest {

	private static AcquistoModel classUnderTest;
	private static AcquistoBean bean;

	@BeforeAll
	static void setUp() throws Exception {

		classUnderTest = new AcquistoModel();

		assertNotNull(classUnderTest);

	}

	@Test
	void testDoRetrieveByEmailinDB() throws Exception {

		System.out.println("- doRetrieveByEmail -");
		
		UtenteBean ubean;
		UtenteModel umodel = new UtenteModel();
		ubean = new UtenteBean();
		ubean.setEmail("francesco@mail.com");
		ubean.setPass("password");
		ubean.setTipo("cliente");
		umodel.insert(ubean);
		
		ClienteBean cbean;
		ClienteModel cmodel = new ClienteModel();
		cbean = new ClienteBean();
		cbean.setEmail_cliente(ubean.getEmail());
		cbean.setNome_cliente("luca");
		cbean.setCognome_cliente("garelli");
		cbean.setIndirizzo("Via Tasso 33 Salerno 84100");
		cbean.setTelefono("3452304239");
		cmodel.insert(cbean);
		
		bean = new AcquistoBean();
		bean.setEmail_utente(ubean.getEmail());
		bean.setTotale(25);
		bean.setData_acquisto(Date.valueOf("2011-02-02"));
		classUnderTest.insert(bean);
		
		ArrayList<AcquistoBean> list = classUnderTest.doRetrieveByEmail(ubean.getEmail());

		assertNotEquals(0, list.size());

		String emailTmp = null;

		for (AcquistoBean temp : list) {
			emailTmp = temp.getEmail_utente();
		}
		classUnderTest.doDeleteByKey(bean.getData_acquisto(), bean.getEmail_utente());
		cmodel.doDeleteByKey(ubean.getEmail());
		assertEquals(ubean.getEmail(), emailTmp);
		umodel.doDeleteByKey(ubean.getEmail());

	}

	@Test
	void testDoRetrieveByEmailNonInDB() throws Exception {

		System.out.println("- doRetrieveByEmail -");

		ArrayList<AcquistoBean> list = classUnderTest.doRetrieveByEmail("a@b.com");

		assertEquals(0, list.size());

	}

	@Test
	void testDoRetrieveByKeyInDB() throws Exception {

		System.out.println("- doRetrieveByKey -");
		
		UtenteBean ubean;
		UtenteModel umodel = new UtenteModel();
		ubean = new UtenteBean();
		ubean.setEmail("francesco@mail.com");
		ubean.setPass("password");
		ubean.setTipo("cliente");
		umodel.insert(ubean);
		
		ClienteBean cbean;
		ClienteModel cmodel = new ClienteModel();
		cbean = new ClienteBean();
		cbean.setEmail_cliente(ubean.getEmail());
		cbean.setNome_cliente("luca");
		cbean.setCognome_cliente("garelli");
		cbean.setIndirizzo("Via Tasso 33 Salerno 84100");
		cbean.setTelefono("3452304239");
		cmodel.insert(cbean);
		
		bean = new AcquistoBean();
		bean.setEmail_utente(ubean.getEmail());
		bean.setTotale(25);
		bean.setData_acquisto(Date.valueOf("2011-02-02"));
		classUnderTest.insert(bean);

		ArrayList<AcquistoBean> list = classUnderTest.doRetrieveByKey(bean.getData_acquisto(), bean.getEmail_utente());

		assertNotEquals(0, list.size());

		String emailTmp = null;
		Date Date = null;

		for (AcquistoBean temp : list) {
			emailTmp = temp.getEmail_utente();
			Date = temp.getData_acquisto();
		}
		assertEquals(bean.getEmail_utente(), emailTmp);
		assertEquals(bean.getData_acquisto().toString(), Date.toString());
		classUnderTest.doDeleteByKey(bean.getData_acquisto(), bean.getEmail_utente());
		cmodel.doDeleteByKey(ubean.getEmail());
		umodel.doDeleteByKey(ubean.getEmail());
		

	}

	@Test
	void testDoRetrieveByKeyNonInDB() throws Exception {

		System.out.println("- doRetrieveByKey -");

		String str = "2019-02-25";
		Date data = Date.valueOf(str);

		ArrayList<AcquistoBean> list = classUnderTest.doRetrieveByKey(data, "a@b.com");

		assertEquals(0, list.size());

	}

	@Test
	void testInsertNoInDB() throws Exception {

		System.out.println("- Insert -");

		UtenteBean ubean;
		UtenteModel umodel = new UtenteModel();
		ubean = new UtenteBean();
		ubean.setEmail("francesco@mail.com");
		ubean.setPass("password");
		ubean.setTipo("cliente");
		umodel.insert(ubean);
		
		ClienteBean cbean;
		ClienteModel cmodel = new ClienteModel();
		cbean = new ClienteBean();
		cbean.setEmail_cliente(ubean.getEmail());
		cbean.setNome_cliente("luca");
		cbean.setCognome_cliente("garelli");
		cbean.setIndirizzo("Via Tasso 33 Salerno 84100");
		cbean.setTelefono("3452304239");
		cmodel.insert(cbean);
		
		bean = new AcquistoBean();
		bean.setEmail_utente(ubean.getEmail());
		bean.setTotale(25);
		bean.setData_acquisto(Date.valueOf("2011-02-02"));
		classUnderTest.insert(bean);
		
		ArrayList<AcquistoBean> result = classUnderTest.doRetrieveByKey(bean.getData_acquisto(), ubean.getEmail());

		assertNotNull(result);

		String emailTmp = null;
		Date dataTmp = null;
		for (AcquistoBean temp : result) {
			emailTmp = temp.getEmail_utente();
			dataTmp = temp.getData_acquisto();
		}
		
		assertEquals(bean.getEmail_utente(), emailTmp);
		assertEquals(bean.getData_acquisto().toString(), dataTmp.toString());
		classUnderTest.doDeleteByKey(bean.getData_acquisto(), bean.getEmail_utente());
		cmodel.doDeleteByKey(ubean.getEmail());
		umodel.doDeleteByKey(ubean.getEmail());

	}

}
