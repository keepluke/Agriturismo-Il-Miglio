package ilmiglio.model;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class PrenotazioneModelTest {

	private static PrenotazioneModel classUnderTest;
	private static PrenotazioneBean bean;
	
	private static UtenteModel uModel;
	private static UtenteBean uBean;

	private static ClienteModel cModel;
	private static ClienteBean cBean;

	@BeforeAll
	static void setUp() throws Exception {

		classUnderTest = new PrenotazioneModel();

		assertNotNull(classUnderTest);

	}

	@Test
	void testDoRetrieveByKeyPrenotazioneInDB() throws Exception {

		System.out.println("- doRetrieveByKey -");
		
		uModel = new UtenteModel();
		uBean = new UtenteBean();
		uBean.setEmail("pasquale@mail.com");
		uBean.setPass("password");
		uBean.setTipo("cliente");
		uModel.insert(uBean);

		cModel = new ClienteModel();
		cBean = new ClienteBean();
		cBean.setEmail_cliente("pasquale@mail.com");
		cBean.setNome_cliente("luca");
		cBean.setCognome_cliente("garelli");
		cBean.setIndirizzo("Via Tasso 33 Salerno 84100");
		cBean.setTelefono("3452304239");
		cModel.doDeleteByKey(cBean.getEmail_cliente());
		cModel.insert(cBean);
		
		bean = new PrenotazioneBean();
		bean.setEmail(cBean.getEmail_cliente());
		String str = "2027-11-31";
		bean.setData(Date.valueOf(str));
		bean.setCommento("testo di prova");
		bean.setPosti(5);
		bean.setOrario("pranzo");
		classUnderTest.insert(bean);
		
		PrenotazioneBean result = new PrenotazioneBean();
		result = classUnderTest.doRetrieveByKey(bean.getData().toString(), bean.getEmail());
		classUnderTest.doDelete(bean.getEmail(), bean.getData().toString());
		cModel.doDeleteByKey(uBean.getEmail());
		uModel.doDeleteByKey(uBean.getEmail());
		System.out.println(result);
		assertNotNull(result);
		assertEquals(bean.getEmail(), result.getEmail());
		assertEquals(bean.getData().toString(), result.getData().toString());
		classUnderTest.doDelete(bean.getEmail(), bean.getData().toString());
		
		

	}

	@Test
	void testDoRetrieveByKeyNonInDB() throws Exception {

		System.out.println("- doRetrieveByKey -");
		
		bean = classUnderTest.doRetrieveByKey("2029-09-27", "a@b.com");
		assertNull(bean);

	}

	@Test
	void testInsertNonInDB() throws Exception {

		System.out.println("- Insert -");

		bean = new PrenotazioneBean();
		bean.setEmail("mario@mail.com");
		String str = "2027-11-31";
		bean.setData(Date.valueOf(str));
		bean.setCommento("testo di prova");
		bean.setPosti(5);
		bean.setOrario("pranzo");
		classUnderTest.insert(bean);

		PrenotazioneBean result = new PrenotazioneBean();
		result = classUnderTest.doRetrieveByKey(bean.getData().toString(), bean.getEmail());
		classUnderTest.doDelete(bean.getEmail(), bean.getData().toString());
		assertEquals(bean.getEmail(), result.getEmail());
		assertEquals(bean.getData().toString(), result.getData().toString());

	}

	@Test
	void testInsertGiaInDB() throws Exception {

		System.out.println("- Insert -");
		
		uModel = new UtenteModel();
		uBean = new UtenteBean();
		uBean.setEmail("pasquale@mail.com");
		uBean.setPass("password");
		uBean.setTipo("cliente");
		uModel.insert(uBean);

		cModel = new ClienteModel();
		cBean = new ClienteBean();
		cBean.setEmail_cliente("pasquale@mail.com");
		cBean.setNome_cliente("luca");
		cBean.setCognome_cliente("garelli");
		cBean.setIndirizzo("Via Tasso 33 Salerno 84100");
		cBean.setTelefono("3452304239");
		cModel.doDeleteByKey(cBean.getEmail_cliente());
		cModel.insert(cBean);

		PrenotazioneBean pBean = new PrenotazioneBean();
		PrenotazioneModel pModel = new PrenotazioneModel();
		
		pBean.setEmail(cBean.getEmail_cliente());
		String str = "2027-11-31";
		pBean.setData(Date.valueOf(str));
		pBean.setCommento("testo di prova");
		pBean.setPosti(5);
		pBean.setOrario("pranzo");
		pModel.insert(pBean);
		
		bean = new PrenotazioneBean();
		bean.setEmail(cBean.getEmail_cliente());
		bean.setData(Date.valueOf(str));
		bean.setCommento("testo di prova");
		bean.setPosti(5);
		bean.setOrario("pranzo");
		boolean exc = false;
		try {
			classUnderTest.insert(bean);
		} catch (SQLException e) {
			exc = true;
		}
		
		pModel.doDelete(pBean.getEmail(), pBean.getData().toString());
		cModel.doDeleteByKey(uBean.getEmail());
		uModel.doDeleteByKey(uBean.getEmail());
		
		assertTrue(exc);

	}

	@Test
	void testDoRetrieveAll() throws Exception {

		System.out.println("- doRetrieveAll -");
		
		uModel = new UtenteModel();
		uBean = new UtenteBean();
		uBean.setEmail("pasquale@mail.com");
		uBean.setPass("password");
		uBean.setTipo("cliente");
		uModel.insert(uBean);

		cModel = new ClienteModel();
		cBean = new ClienteBean();
		cBean.setEmail_cliente("pasquale@mail.com");
		cBean.setNome_cliente("luca");
		cBean.setCognome_cliente("garelli");
		cBean.setIndirizzo("Via Tasso 33 Salerno 84100");
		cBean.setTelefono("3452304239");
		cModel.doDeleteByKey(cBean.getEmail_cliente());
		cModel.insert(cBean);

		PrenotazioneBean pBean = new PrenotazioneBean();
		PrenotazioneModel pModel = new PrenotazioneModel();
		
		pBean.setEmail(cBean.getEmail_cliente());
		String str = "2027-11-31";
		pBean.setData(Date.valueOf(str));
		pBean.setCommento("testo di prova");
		pBean.setPosti(5);
		pBean.setOrario("pranzo");
		pModel.insert(pBean);

		ArrayList<PrenotazioneBean> list = (ArrayList<PrenotazioneBean>) classUnderTest.doRetrieveAll();
		assertNotEquals(0, list.size());
		
		pModel.doDelete(pBean.getEmail(), pBean.getData().toString());
		cModel.doDeleteByKey(uBean.getEmail());
		uModel.doDeleteByKey(uBean.getEmail());
		
	}

	@Test
	void testDoRetrieveAllByEmail() throws Exception {

		System.out.println("- doRetrieveAll -");
		
		uModel = new UtenteModel();
		uBean = new UtenteBean();
		uBean.setEmail("pasquale@mail.com");
		uBean.setPass("password");
		uBean.setTipo("cliente");
		uModel.insert(uBean);

		cModel = new ClienteModel();
		cBean = new ClienteBean();
		cBean.setEmail_cliente("pasquale@mail.com");
		cBean.setNome_cliente("luca");
		cBean.setCognome_cliente("garelli");
		cBean.setIndirizzo("Via Tasso 33 Salerno 84100");
		cBean.setTelefono("3452304239");
		cModel.doDeleteByKey(cBean.getEmail_cliente());
		cModel.insert(cBean);

		PrenotazioneBean pBean = new PrenotazioneBean();
		PrenotazioneModel pModel = new PrenotazioneModel();
		
		pBean.setEmail(cBean.getEmail_cliente());
		String str = "2027-11-31";
		pBean.setData(Date.valueOf(str));
		pBean.setCommento("testo di prova");
		pBean.setPosti(5);
		pBean.setOrario("pranzo");
		pModel.insert(pBean);

		ArrayList<PrenotazioneBean> list = (ArrayList<PrenotazioneBean>) classUnderTest
				.doRetrieveAllByEmail(cBean.getEmail_cliente());
		assertNotEquals(0, list.size());
		pModel.doDelete(pBean.getEmail(), pBean.getData().toString());
		cModel.doDeleteByKey(uBean.getEmail());
		uModel.doDeleteByKey(uBean.getEmail());
		
	}

	@Test
	void testDoDeleteInDB() throws Exception {

		System.out.println("- doDelete -");

		bean = new PrenotazioneBean();
		bean.setEmail("mario@mail.com");
		bean.setData(Date.valueOf("2030-10-27"));
		bean.setCommento("testo di prova");
		bean.setPosti(5);
		bean.setOrario("pranzo");

		classUnderTest.insert(bean);

		PrenotazioneBean result = classUnderTest.doRetrieveByKey("2030-10-27", bean.getEmail());
		boolean exc;

		if (result.getEmail().equals(bean.getEmail()) && result.getData().equals(bean.getData())) {
			exc = true;
		} else
			exc = false;

		if (exc) {
			classUnderTest.doDelete(bean.getEmail(), bean.getData().toString());
		}
		
		assertTrue(exc);

	}

	@Test
	void testDoDeleteNonInDB() throws Exception {

		System.out.println("- doDelete -");

		PrenotazioneBean result = classUnderTest.doRetrieveByKey("2001-10-27", "a@b.com");

		assertNull(result);

	}

	@Test
	void testControlloPosti() throws Exception {

		System.out.println("- ControlloPosti -");

		uModel = new UtenteModel();
		uBean = new UtenteBean();
		uBean.setEmail("pasquale@mail.com");
		uBean.setPass("password");
		uBean.setTipo("cliente");
		uModel.insert(uBean);

		cModel = new ClienteModel();
		cBean = new ClienteBean();
		cBean.setEmail_cliente("pasquale@mail.com");
		cBean.setNome_cliente("luca");
		cBean.setCognome_cliente("garelli");
		cBean.setIndirizzo("Via Tasso 33 Salerno 84100");
		cBean.setTelefono("3452304239");
		cModel.doDeleteByKey(cBean.getEmail_cliente());
		cModel.insert(cBean);
		
		bean = new PrenotazioneBean();
		bean.setEmail(uBean.getEmail());
		bean.setData(Date.valueOf("2019-02-27"));
		bean.setCommento("testo di prova");
		bean.setPosti(5);
		bean.setOrario("pranzo");

		classUnderTest.insert(bean);

		int i = classUnderTest.controlloPosti("2019-02-27", "pranzo");
		boolean exc = false;

		if (i >= 0)
			exc = true;
		
		classUnderTest.doDelete(bean.getEmail(), bean.getData().toString());
		cModel.doDeleteByKey(uBean.getEmail());
		uModel.doDeleteByKey(uBean.getEmail());
		assertTrue(exc);

	}

}
