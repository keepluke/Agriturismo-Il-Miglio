package ilmiglio.model;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class UtenteModelTest {

	private static UtenteModel classUnderTest;
	private static UtenteBean bean;

	/**
	 * Setta classe undertest e bean prima del testretrievebykey
	 * 
	 * @throws Exception
	 */
	@BeforeAll
	static void setUp() throws Exception {

		classUnderTest = new UtenteModel();

		assertNotNull(classUnderTest);

	}

	/**
	 * Testa il metodo doRetieveByKey con un utente presente nel DB
	 * 
	 * @throws Exception
	 */
	@Test
	void testDoRetrieveByKeyUtenteInDB() throws Exception {

		System.out.println("- doRetrieveByKey -");
		
		UtenteModel uModel = new UtenteModel();
		UtenteBean uBean = new UtenteBean();
		uBean.setEmail("pasquale@mail.com");
		uBean.setPass("password");
		uBean.setTipo("cliente");
		uModel.insert(uBean);
		
		bean = classUnderTest.doRetrieveByKey(uBean.getEmail());
		assertNotNull(bean);
		assertEquals(uBean.getEmail(), bean.getEmail());
		uModel.doDeleteByKey(uBean.getEmail());
	}

	/**
	 * Testa il metodo doRetrieveByKey con utente non presente in DB
	 * 
	 * @throws Exception
	 */
	@Test
	void testDoRetrieveByKeyNonInDB() throws Exception {

		System.out.println("- doRetrieveByKey -");
		bean = classUnderTest.doRetrieveByKey("a@b.com");
		assertNull(bean);

	}

	/**
	 * Test del metodo insert non presente nel DB
	 * 
	 * @throws Exception
	 */
	@Test
	void testInsertUtenteNonInDB() throws Exception {

		System.out.println("- Insert -");
		bean = new UtenteBean();
		bean.setEmail("francesco@mail.com");
		bean.setPass("password");
		bean.setTipo("cliente");
		classUnderTest.insert(bean);
		UtenteBean result = classUnderTest.doRetrieveByKey("francesco@mail.com");
		classUnderTest.doDeleteByKey(bean.getEmail());
		assertNotNull(result);
		assertEquals("francesco@mail.com", result.getEmail());

	}

	/**
	 * Test del metodo insert presente nel DB
	 * 
	 * @throws Exception
	 */
	@Test
	void testInsertUtenteInDB() throws Exception {

		System.out.println("- Insert -");
		bean = new UtenteBean();
		bean.setEmail("giancarloiannone@mail.com");
		bean.setPass("giancarlo");
		bean.setTipo("admin");
		boolean exc = false;
		try {
			classUnderTest.insert(bean);
		} catch (SQLException e) {
			exc = true;
		}

		assertTrue(exc);

	}

}
