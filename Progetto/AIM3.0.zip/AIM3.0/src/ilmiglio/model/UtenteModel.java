
package ilmiglio.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import ilmiglio.util.DriverManagerConnectionPool;

public class UtenteModel {

	/**
	 * Restituisce un utente data la email
	 * 
	 * @param email String
	 * @return bean UtenteBean
	 * @throws SQLException
	 */
	public synchronized UtenteBean doRetrieveByKey(String email) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		try {
			connection = DriverManagerConnectionPool.getConnection();

			String sql = "select * from utente where email = ?;";

			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setString(1, email);

			rs = preparedStatement.executeQuery();

			if (rs.next()) {
				UtenteBean bean = new UtenteBean();
				bean.setEmail(rs.getString("email"));
				bean.setPass(rs.getString("pass"));
				bean.setTipo(rs.getString("tipo"));
				return bean;
			} else
				return null;
		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

	/**
	 * Inserisce un nuovo utente
	 * 
	 * @param utente UtenteBean
	 * @throws SQLException
	 */
	public synchronized void insert(UtenteBean utente) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			connection = DriverManagerConnectionPool.getConnection();

			String sql = "insert into utente " + "(email, pass, tipo) " + "values (?, ?, ?);";

			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setString(1, utente.getEmail());
			preparedStatement.setString(2, utente.getPass());
			preparedStatement.setString(3, utente.getTipo());

			preparedStatement.executeUpdate();

			connection.commit();
		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}

	}

	public synchronized void doDeleteByKey(String email) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			connection = DriverManagerConnectionPool.getConnection();
			String sql = "delete from utente where email = ?;";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, email);
			preparedStatement.executeUpdate();
			connection.commit();
		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

}
