package ilmiglio.model;

import java.sql.Date;

public class AcquistoBean {
	private int codice_scontrino;
	private Date data_acquisto;
	private double totale;
	private String email_utente;
	
	public Date getData_acquisto() {
		return data_acquisto;
	}
	public void setData_acquisto(Date data_acquisto) {
		this.data_acquisto = data_acquisto;
	}
	
	public double getTotale() {
		return totale;
	}
	public void setTotale(double totale) {
		this.totale = totale;
	}
	public String getEmail_utente() {
		return email_utente;
	}
	public void setEmail_utente(String email_utente) {
		this.email_utente = email_utente;
	}
	public int getCodice_scontrino() {
		return codice_scontrino;
	}
	public void setCodice_scontrino(int codice_scontrino) {
		this.codice_scontrino = codice_scontrino;
	}
	
}
