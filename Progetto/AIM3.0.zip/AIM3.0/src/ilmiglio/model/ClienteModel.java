package ilmiglio.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import ilmiglio.util.DriverManagerConnectionPool;

public class ClienteModel {
	/**
	 * Restituisce un cliente data una email
	 * 
	 * @param email_cliente
	 * @return bean ClienteBean
	 * @throws SQLException
	 */
	public synchronized ClienteBean doRetrieveByKey(String email_cliente) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		try {
			connection = DriverManagerConnectionPool.getConnection();

			String sql = "select * from cliente where email_cliente = ?;";

			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setString(1, email_cliente);

			rs = preparedStatement.executeQuery();

			if (rs.next()) {
				ClienteBean bean = new ClienteBean();
				bean.setEmail_cliente(rs.getString("email_cliente"));
				bean.setNome_cliente(rs.getString("nome_cliente"));
				bean.setCognome_cliente(rs.getString("cognome_cliente"));
				bean.setTelefono(rs.getString("telefono"));
				bean.setIndirizzo(rs.getString("indirizzo"));

				return bean;
			} else
				return null;
		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

	/**
	 * Inserisce un nuovo cliente all'interno del DB
	 * 
	 * @param cliente ClienteBean
	 * @throws SQLException
	 */
	public synchronized void insert(ClienteBean cliente) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			connection = DriverManagerConnectionPool.getConnection();

			String sql = "insert into cliente " + "(email_cliente, nome_cliente, cognome_cliente, indirizzo, telefono) "
					+ "values ( ?, ?, ?, ? ,?);";

			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setString(1, cliente.getEmail_cliente());
			preparedStatement.setString(2, cliente.getNome_cliente());
			preparedStatement.setString(3, cliente.getCognome_cliente());
			preparedStatement.setString(4, cliente.getIndirizzo());
			preparedStatement.setString(5, cliente.getTelefono());

			preparedStatement.executeUpdate();

			connection.commit();
		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

	/**
	 * Aggiorna i valori di un cliente
	 * 
	 * @param cliente ClienteBean
	 * @throws SQLException
	 */
	public synchronized void update(ClienteBean cliente) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			connection = DriverManagerConnectionPool.getConnection();

			String sql = "update cliente set cliente.indirizzo = ?, cliente.telefono = ? where cliente.email_cliente = ?;";

			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setString(1, cliente.getIndirizzo());
			preparedStatement.setString(2, cliente.getTelefono());
			preparedStatement.setString(3, cliente.getEmail_cliente());

			preparedStatement.executeUpdate();

			connection.commit();
		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}
	
	public synchronized void doDeleteByKey(String email) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			connection = DriverManagerConnectionPool.getConnection();
			String sql = "delete from cliente where email_cliente = ?;";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, email);
			preparedStatement.executeUpdate();
			connection.commit();
		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}
	
}
