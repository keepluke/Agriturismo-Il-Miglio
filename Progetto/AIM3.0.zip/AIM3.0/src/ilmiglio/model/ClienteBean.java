package ilmiglio.model;

public class ClienteBean {
	private String nome_cliente;
	private String cognome_cliente;
	private String email_cliente;
	private String telefono;
	private String indirizzo;
	
	public String getNome_cliente() {
		return nome_cliente;
	}
	public void setNome_cliente(String nome_cliente) {
		this.nome_cliente = nome_cliente;
	}
	public String getCognome_cliente() {
		return cognome_cliente;
	}
	public void setCognome_cliente(String cognome_cliente) {
		this.cognome_cliente = cognome_cliente;
	}
	public String getEmail_cliente() {
		return email_cliente;
	}
	public void setEmail_cliente(String email_cliente) {
		this.email_cliente = email_cliente;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public String getIndirizzo() {
		return indirizzo;
	}
	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}
	
	
	
}
