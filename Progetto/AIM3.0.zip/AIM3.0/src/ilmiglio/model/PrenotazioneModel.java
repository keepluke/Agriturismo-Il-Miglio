package ilmiglio.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import ilmiglio.util.DriverManagerConnectionPool;

public class PrenotazioneModel {

	/**
	 * Restituisce una prenotazione data la date e l'email del cliente
	 * 
	 * @param data  String
	 * @param email String
	 * @return bean PrenotazioneBean
	 * @throws SQLException
	 */
	public synchronized PrenotazioneBean doRetrieveByKey(String data, String email) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		try {
			connection = DriverManagerConnectionPool.getConnection();

			String sql = "select * from prenotazione where data_prenotazione = ? AND email_cliente = ?;";

			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setString(1, data);
			preparedStatement.setString(2, email);

			rs = preparedStatement.executeQuery();

			PrenotazioneBean bean = null;

			if (rs.next()) {
				bean = new PrenotazioneBean();
				bean.setEmail(rs.getString("email_cliente"));
				bean.setData(rs.getDate("data_prenotazione"));
				bean.setOrario(rs.getString("orario"));
				bean.setPosti(rs.getInt("num_posti"));
				bean.setCommento(rs.getString("commento"));
			}

			return bean;
		}

		finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

	/**
	 * Inserisce una nuova prenotazione
	 * 
	 * @param prenotazione PrenotazioneBean
	 * @throws SQLException
	 */
	public synchronized void insert(PrenotazioneBean prenotazione) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = DriverManagerConnectionPool.getConnection();

			// inserisco la prenotazione
			String sql = "insert into prenotazione "
					+ "(data_prenotazione, orario, email_cliente, num_posti, commento) " + "values (?, ?, ?, ?, ?);";

			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setDate(1, prenotazione.getData());
			preparedStatement.setString(2, prenotazione.getOrario());
			preparedStatement.setString(3, prenotazione.getEmail());
			preparedStatement.setInt(4, prenotazione.getPosti());
			preparedStatement.setString(5, prenotazione.getCommento());

			preparedStatement.executeUpdate();

			connection.commit();

		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

	/**
	 * Restituisce tutte le prenotazioni effettuate
	 * 
	 * @return collection Collection<PrenotazioneBean>
	 * @throws SQLException
	 */
	public synchronized Collection<PrenotazioneBean> doRetrieveAll() throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		Collection<PrenotazioneBean> collection = new ArrayList<PrenotazioneBean>();

		try {
			connection = DriverManagerConnectionPool.getConnection();

			String sql = "select * from prenotazione order by data_prenotazione desc;";

			preparedStatement = connection.prepareStatement(sql);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				PrenotazioneBean bean = new PrenotazioneBean();
				bean.setEmail(rs.getString("email_cliente"));
				bean.setData(rs.getDate("data_prenotazione"));
				bean.setOrario(rs.getString("orario"));
				bean.setPosti(rs.getInt("num_posti"));
				bean.setCommento(rs.getString("commento"));
				collection.add(bean);
			}

			return collection;
		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

	/**
	 * Contralla se ci sono posti disponibili in una data data e dato orario
	 * 
	 * @param data   String
	 * @param orario String
	 * @return num_posti_presi int
	 * @throws SQLException
	 */
	public synchronized int controlloPosti(String data, String orario) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		int num_posti_presi = 0;

		try {
			connection = DriverManagerConnectionPool.getConnection();
			String sql = "select * from prenotazione where data_prenotazione = ? and orario = ?;";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, data);
			preparedStatement.setString(2, orario);
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				PrenotazioneBean bean = new PrenotazioneBean();
				bean.setPosti(rs.getInt("num_posti"));
				num_posti_presi += bean.getPosti();
			}
			return num_posti_presi;
		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

	/**
	 * Restituisce un ArrayList di prenotazioni data una mail
	 * 
	 * @param email String
	 * @return lista ArrayList<PrenotazioneBean>
	 * @throws SQLException
	 */
	public synchronized ArrayList<PrenotazioneBean> doRetrieveAllByEmail(String email) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		try {
			connection = DriverManagerConnectionPool.getConnection();
			String sql = "select * from prenotazione where email_cliente = ?;";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, email);
			rs = preparedStatement.executeQuery();
			ArrayList<PrenotazioneBean> lista = new ArrayList<PrenotazioneBean>();
			while (rs.next()) {
				PrenotazioneBean bean = new PrenotazioneBean();
				bean.setEmail(rs.getString("email_cliente"));
				bean.setData(rs.getDate("data_prenotazione"));
				bean.setOrario(rs.getString("orario"));
				bean.setPosti(rs.getInt("num_posti"));
				bean.setCommento(rs.getString("commento"));
				lista.add(bean);
				System.out.println("aggiunto");
			}

			return lista;
		}

		finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

	/**
	 * Cancella una prenotazione data una data e una mail
	 * 
	 * @param email String
	 * @param date  String
	 * @throws SQLException
	 */
	public synchronized void doDelete(String email, String date) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			connection = DriverManagerConnectionPool.getConnection();

			String sql = "delete from prenotazione where data_prenotazione = ? AND email_cliente = ?;";

			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setString(1, date);
			preparedStatement.setString(2, email);
			System.out.println(sql);
			preparedStatement.executeUpdate();

			connection.commit();
		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}
}
