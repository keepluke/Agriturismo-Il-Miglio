package ilmiglio.model;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import ilmiglio.util.DriverManagerConnectionPool;
import ilmiglio.model.ProdottoBean;

public class ProdottoModel {

	/**
	 * Restituisce un prodotto dato il codice
	 * 
	 * @param codice int
	 * @return bean ProdottoBean
	 * @throws SQLException
	 */
	public synchronized ProdottoBean doRetrieveByKey(int codice) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		try {
			connection = DriverManagerConnectionPool.getConnection();

			String sql = "select * from prodotto where codice = ?;";

			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setInt(1, codice);

			rs = preparedStatement.executeQuery();

			if (rs.next()) {
				ProdottoBean bean = new ProdottoBean();
				bean.setCodice(rs.getInt("codice"));
				bean.setNome_tipo(rs.getString("nome_tipo"));
				bean.setQuantit�_disponibile(rs.getInt("quantita_disponibile"));
				bean.setData_produzione(rs.getDate("data_produzione"));
				bean.setData_scadenza(rs.getDate("data_scadenza"));
				bean.setPrezzo(rs.getDouble("prezzo"));
				bean.setFotoPath("foto_path");
				InputStream in = rs.getBinaryStream("foto");
				bean.setIn(in);
				return bean;
			} else
				return null;
		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

	/**
	 * Restituisce una collezione di prodotti
	 * 
	 * @return collection Collection<ProdottoBean>
	 * @throws SQLException
	 */
	public synchronized Collection<ProdottoBean> doRetrieveAll() throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		Collection<ProdottoBean> collection = new ArrayList<ProdottoBean>();

		try {
			connection = DriverManagerConnectionPool.getConnection();

			String sql = "select * from prodotto;";

			preparedStatement = connection.prepareStatement(sql);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				ProdottoBean bean = new ProdottoBean();
				bean.setCodice(rs.getInt("codice"));
				bean.setNome_tipo(rs.getString("nome_tipo"));
				bean.setQuantit�_disponibile(rs.getInt("quantita_disponibile"));
				bean.setData_produzione(rs.getDate("data_produzione"));
				bean.setData_scadenza(rs.getDate("data_scadenza"));
				bean.setPrezzo(rs.getDouble("prezzo"));
				bean.setFotoPath(rs.getString("foto_path"));
				InputStream in = rs.getBinaryStream("foto");
				bean.setIn(in);
				collection.add(bean);
			}

			return collection;
		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

	/**
	 * Restituisce l'InputStream di una immagine dato il codice del prodotto
	 * 
	 * @param codice int
	 * @return in InputStream
	 * @throws SQLException
	 */
	public synchronized InputStream findImageById(int codice) throws SQLException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			connection = DriverManagerConnectionPool.getConnection();

			System.out.println("input s:");
			String sql = "select foto from prodotto " + "where " + "prodotto.codice = ?"; // SELECT foto FROM
																							// agriturismo.prodotto
																							// WHERE codice = '21231';
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, codice);
			rs = preparedStatement.executeQuery();
			if (rs.next()) {
				InputStream in = rs.getBinaryStream("foto");
				System.out.println("input s: " + in);
				return in;
			} else {
				System.out.println("restituisco null");
				return null;
			}
		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}

		}
	}

	/**
	 * Inserisce un nuovo prodotto
	 * 
	 * @param prodotto ProdottoBean
	 * @throws SQLException
	 */
	public synchronized void insert(ProdottoBean prodotto) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			connection = DriverManagerConnectionPool.getConnection();

			String sql = "insert into prodotto "
					+ "(codice, nome_tipo, quantita_disponibile, data_produzione, data_scadenza, prezzo,foto_path, foto) "
					+ "values (?, ?, ?, ?, ?, ?, ?, ?);";

			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setInt(1, prodotto.getCodice());
			preparedStatement.setString(2, prodotto.getNome_tipo());
			preparedStatement.setInt(3, prodotto.getQuantit�_disponibile());
			preparedStatement.setDate(4, prodotto.getData_produzione());
			preparedStatement.setDate(5, prodotto.getData_scadenza());
			preparedStatement.setDouble(6, prodotto.getPrezzo());
			preparedStatement.setString(7, prodotto.getFotoPath());
			preparedStatement.setBinaryStream(8, prodotto.getFis(), prodotto.getLenghtImage());
			preparedStatement.executeUpdate();

			connection.commit();
		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

	/**
	 * Elimina un prodotto dato il codice
	 * 
	 * @param codice int
	 * @throws SQLException
	 */
	public synchronized void doDelete(int codice) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			connection = DriverManagerConnectionPool.getConnection();
			ESoggettoModel esoggettoModel = new ESoggettoModel();
			esoggettoModel.doDelete(codice);
			String sql = "delete from prodotto where codice = ?;";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, codice);
			preparedStatement.executeUpdate();
			connection.commit();
		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

	/**
	 * Aggiorna la quantit� di un prodotto dato il codice e la nuova quantit�
	 * 
	 * @param codice   int
	 * @param quantita int
	 * @throws SQLException
	 */
	public synchronized void doUpdateQuantita(int codice, int quantita) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		boolean alreadyExists = (doRetrieveByKey(codice) != null);

		if (alreadyExists) {
			// modifica un prodotto esistente
			String sql = "update prodotto set prodotto.quantita_disponibile = ?" + " where prodotto.codice = ?;";

			try {
				connection = DriverManagerConnectionPool.getConnection();
				preparedStatement = connection.prepareStatement(sql);
				preparedStatement.setInt(1, quantita);
				preparedStatement.setInt(2, codice);
				preparedStatement.executeUpdate();
				connection.commit();

			} finally {
				try {
					if (preparedStatement != null)
						preparedStatement.close();
				} finally {
					DriverManagerConnectionPool.releaseConnection(connection);
				}
			}

		}
	}

	/**
	 * Aggiorna il prodotto dato un ProdottoBean
	 * 
	 * @param prodotto ProdottoBean
	 * @throws SQLException
	 */
	public synchronized void update(ProdottoBean prodotto) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			connection = DriverManagerConnectionPool.getConnection();
			String sql = "update prodotto set prodotto.nome_tipo = ?, prodotto.quantita_disponibile = ?, prodotto.prezzo = ? where prodotto.codice = ?;";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, prodotto.getNome_tipo());
			preparedStatement.setInt(2, prodotto.getQuantit�_disponibile());
			preparedStatement.setDouble(3, prodotto.getPrezzo());
			preparedStatement.setInt(4, prodotto.getCodice());
			preparedStatement.executeUpdate();
			connection.commit();
		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}
}
