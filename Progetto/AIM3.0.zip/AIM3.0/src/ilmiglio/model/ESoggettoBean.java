package ilmiglio.model;

public class ESoggettoBean {
	private int codice_prodotto;
	private int codice_scontrino;
	private int quantita;
	
	public int getCodice_prodotto() {
		return codice_prodotto;
	}
	public void setCodice_prodotto(int codice_prodotto) {
		this.codice_prodotto = codice_prodotto;
	}
	public int getCodice_scontrino() {
		return codice_scontrino;
	}
	public void setCodice_scontrino(int codice_scontrino) {
		this.codice_scontrino = codice_scontrino;
	}
	public int getQuantita() {
		return quantita;
	}
	public void setQuantita(int quantita) {
		this.quantita = quantita;
	}
}
