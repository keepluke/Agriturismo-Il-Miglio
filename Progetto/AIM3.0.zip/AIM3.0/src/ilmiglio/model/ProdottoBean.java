package ilmiglio.model;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Date;

public class ProdottoBean {
	private int codice;
	private String nome_tipo;
	private int quantit�_disponibile;
	private Date data_produzione;
	private Date data_scadenza;
	private double prezzo;
	private static final String parzialPath = "C:\\Users\\Romi\\Desktop\\workspace\\AIM3.0\\WebContent\\images\\immaginiShop";
	private String formato;
	private String fotoPath;
	private FileInputStream fis;
	private int lenghtImage;
	private InputStream in;
	
	public String takepath() {
		String cod = "" + codice;
		String path = null;
		if(formato != null && cod != null) {
			path = (parzialPath + cod + formato).trim();
		}
		else {
			path = "invalid path";
		}
		return path;
	}
	public int getCodice() {
		return codice;
	}
	public void setCodice(int codice) {
		this.codice = codice;
	}
	public String getNome_tipo() {
		return nome_tipo;
	}
	public void setNome_tipo(String nome_tipo) {
		this.nome_tipo = nome_tipo;
	}
	public int getQuantit�_disponibile() {
		return quantit�_disponibile;
	}
	public void setQuantit�_disponibile(int quantit�_disponibile) {
		this.quantit�_disponibile = quantit�_disponibile;
	}
	public Date getData_produzione() {
		return data_produzione;
	}
	public void setData_produzione(Date data_produzione) {
		this.data_produzione = data_produzione;
	}
	public Date getData_scadenza() {
		return data_scadenza;
	}
	public void setData_scadenza(Date data_scadenza) {
		this.data_scadenza = data_scadenza;
	}
	public double getPrezzo() {
		return prezzo;
	}
	public void setPrezzo(double prezzo) {
		this.prezzo = prezzo;
	}
	public String getFormato() {
		return formato;
	}
	public void setFormato(String formato) {
		this.formato = "." + formato.replaceAll("image/", "");
		if(this.formato.equals(".jpeg")|| this.formato.equals(".png")) {
			this.formato = ".jpg";
		}
	}

	public String getFotoPath() {
		return fotoPath;
	}

	public void setFotoPath(String fotoPath) {
		this.fotoPath = fotoPath;
	}
	public FileInputStream getFis() {
		return fis;
	}
	public void setFis(FileInputStream fis) {
		this.fis = fis;
	}
	public int getLenghtImage() {
		return lenghtImage;
	}
	public void setLenghtImage(int lenghtImage) {
		this.lenghtImage = lenghtImage;
	}
	public InputStream getIn() {
		return in;
	}
	public void setIn(InputStream in) {
		this.in = in;
	}
}
