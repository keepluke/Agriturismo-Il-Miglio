package ilmiglio.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import ilmiglio.util.DriverManagerConnectionPool;

public class ESoggettoModel {

	/**
	 * Restituisce tramite il codice scrontrino e il codice prodotto l'acquisto
	 * 
	 * @param cod_scontrino int
	 * @param cod_prodotto  int
	 * @return bean ESoggettoBean
	 * @throws SQLException
	 */
	public synchronized ESoggettoBean doRetrieveByKey(int cod_scontrino, int cod_prodotto) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		try {
			connection = DriverManagerConnectionPool.getConnection();

			String sql = "select * from �_soggetto where codice_scontrino = ? and codice_prodotto= ?;";

			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setInt(1, cod_scontrino);
			preparedStatement.setInt(2, cod_prodotto);

			rs = preparedStatement.executeQuery();

			if (rs.next()) {
				ESoggettoBean bean = new ESoggettoBean();
				bean.setCodice_scontrino(cod_scontrino);
				bean.setCodice_prodotto(cod_prodotto);
				bean.setQuantita(rs.getInt("quantita"));
				return bean;
			} else
				return null;
		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

	/**
	 * Inserisce un nuovo scontrino di acquisto
	 * 
	 * @param �_soggetto ESoggettoBean
	 * @throws SQLException
	 */
	public synchronized void insert(ESoggettoBean �_soggetto) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			connection = DriverManagerConnectionPool.getConnection();

			String sql = "insert into �_soggetto " + "(codice_scontrino,codice_prodotto,quantita) "
					+ "values (?, ?,?);";

			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setInt(1, �_soggetto.getCodice_scontrino());
			preparedStatement.setInt(2, �_soggetto.getCodice_prodotto());
			preparedStatement.setInt(3, �_soggetto.getQuantita());

			preparedStatement.executeUpdate();

			connection.commit();
		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

	/**
	 * Cancella uno scontrino tramite il codice prodotto
	 * 
	 * @param codice int
	 * @throws SQLException
	 */
	public synchronized void doDelete(int codice) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			connection = DriverManagerConnectionPool.getConnection();

			String sql = "delete from �_soggetto where codice_prodotto = ?;";

			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setInt(1, codice);

			preparedStatement.executeUpdate();

			connection.commit();
		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}
}
