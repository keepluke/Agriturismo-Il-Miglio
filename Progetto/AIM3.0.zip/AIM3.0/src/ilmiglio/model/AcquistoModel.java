package ilmiglio.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Date;

import ilmiglio.util.DriverManagerConnectionPool;

public class AcquistoModel {

	/**
	 * Restituisce un ArrayList di tutti gli acquisti effettuati da un cliente data
	 * una e-mail
	 * 
	 * @param email String
	 * @return acquisti ArrayList<AcquistoBean>
	 * @throws SQLException
	 */
	public synchronized ArrayList<AcquistoBean> doRetrieveByEmail(String email) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		try {
			connection = DriverManagerConnectionPool.getConnection();

			String sql = "select * from acquisto where email_utente = ? ;";

			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setString(1, email);
			rs = preparedStatement.executeQuery();

			ArrayList<AcquistoBean> acquisti = new ArrayList<>();
			while (rs.next()) {
				AcquistoBean bean = new AcquistoBean();
				bean.setCodice_scontrino(rs.getInt("cod_scontrino"));
				bean.setData_acquisto(rs.getDate("data_acquisto"));
				bean.setEmail_utente(rs.getString("email_utente"));
				bean.setTotale(rs.getDouble("totale"));
				acquisti.add(bean);
			}
			return acquisti;

		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

	/**
	 * Restituisce gli acquisti effettuati in una giornata di un cliente data una
	 * data e una e-mail
	 * 
	 * @param data  Date
	 * @param email String
	 * @return acquisti ArrayList<AcquistoBean>
	 * @throws SQLException
	 */
	public synchronized ArrayList<AcquistoBean> doRetrieveByKey(Date data, String email) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		try {
			connection = DriverManagerConnectionPool.getConnection();

			String sql = "select * from acquisto where data_acquisto = ? and email_utente=? order by cod_scontrino asc;";

			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setDate(1, data);
			preparedStatement.setString(2, email);

			rs = preparedStatement.executeQuery();

			ArrayList<AcquistoBean> acquisti = new ArrayList<>();
			while (rs.next()) {
				AcquistoBean bean = new AcquistoBean();
				bean.setCodice_scontrino(rs.getInt("cod_scontrino"));
				bean.setData_acquisto(rs.getDate("data_acquisto"));
				bean.setEmail_utente(rs.getString("email_utente"));
				bean.setTotale(rs.getDouble("totale"));
				acquisti.add(bean);
			}
			return acquisti;

		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

	/**
	 * Inserisce un nuovo acquisto nel DB
	 * 
	 * @param acquisto AcqistoBean
	 * @throws SQLException
	 */
	public synchronized void insert(AcquistoBean acquisto) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			connection = DriverManagerConnectionPool.getConnection();

			String sql = "insert into acquisto " + "(data_acquisto,email_utente,totale) " + "values (?, ?, ?);";

			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setDate(1, acquisto.getData_acquisto());
			preparedStatement.setString(2, acquisto.getEmail_utente());
			preparedStatement.setDouble(3, acquisto.getTotale());

			preparedStatement.executeUpdate();

			connection.commit();

		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}
	
	public synchronized void doDeleteByKey(Date data, String email) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			connection = DriverManagerConnectionPool.getConnection();
			String sql = "delete from acquisto where data_acquisto = ? and email_utente=?;";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setDate(1, data);
			preparedStatement.setString(2, email);
			preparedStatement.executeUpdate();
			connection.commit();
		} finally {
			try {
				if (!connection.isClosed())
					connection.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

}
