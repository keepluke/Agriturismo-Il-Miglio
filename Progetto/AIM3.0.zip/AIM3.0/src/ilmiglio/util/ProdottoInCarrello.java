package ilmiglio.util;

import ilmiglio.model.ProdottoBean;

public class ProdottoInCarrello {

	private ProdottoBean prodotto;
	private int quantita;
	
	public ProdottoBean getProdotto() {
		return prodotto;
	}
	public int getQuantita() {
		return quantita;
	}
	public void setProdotto(ProdottoBean prodotto) {
		this.prodotto = prodotto;
	}
	public void setQuantita(int quantita) {
		this.quantita = quantita;
	}
}
