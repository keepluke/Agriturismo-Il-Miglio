package ilmiglio.util;

import java.util.ArrayList;

import ilmiglio.model.ProdottoBean;

public class Carrello {

	private ArrayList<ProdottoInCarrello> prodotti;

	public Carrello() {
		prodotti = new ArrayList<ProdottoInCarrello>();
	}

	public void aggiungi(ProdottoBean prodotto) {
		for (ProdottoInCarrello x : prodotti) {
			if (x.getProdotto().getCodice() == prodotto.getCodice()) {
				// ce l'ho gi�
				// aggiorno la quantit�
				x.setQuantita(x.getQuantita() + 1);
				return;
			}
		}
		// altrimenti instanzio un prodottoincarrello
		// con questo prodotto e quantit� = 1
		// e inserisco nell'array
		ProdottoInCarrello prod = new ProdottoInCarrello();
		prod.setProdotto(prodotto);
		prod.setQuantita(1);
		prodotti.add(prod);
	}

	public void rimuovi(ProdottoBean prodotto) {
		for (ProdottoInCarrello x : prodotti) {
			if (x.getProdotto().getCodice() == prodotto.getCodice()) {
				// ho trovato quel prodotto
				int quantita = x.getQuantita();
				if (quantita > 1) {
					quantita--;
					x.setQuantita(quantita);
					return;
				} else {
					prodotti.remove(x);
					return;
				}
			}
		}
	}

	public void rimuoviPerBene(ProdottoBean prodotto) {
		for (ProdottoInCarrello x : prodotti) {
			if (x.getProdotto().getCodice() == prodotto.getCodice()) {
				// ho trovato quel prodotto
				prodotti.remove(x);
				return;
			}
		}
	}
	
	public void clearAll() {
		prodotti.clear();
	}

	public ArrayList<ProdottoInCarrello> getProdotti() {
		return prodotti;
	}

}
