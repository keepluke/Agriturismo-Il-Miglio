package ilmiglio.control;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;

import javax.imageio.ImageIO;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.Part;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ilmiglio.model.ProdottoBean;
import ilmiglio.model.ProdottoModel;

/**
 * Servlet implementation class ServletProdottoAdmin
 */
@WebServlet("/ServletProdottoAdmin")
@MultipartConfig(maxFileSize = 169999999)
public class ServletProdottoAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletProdottoAdmin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("shop.jsp");
		return;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ProdottoBean prodotto = new ProdottoBean();
		prodotto.setCodice(Integer.parseInt(request.getParameter("codice").trim()));
		prodotto.setNome_tipo(request.getParameter("nome_prodotto"));
		prodotto.setQuantit�_disponibile(Integer.parseInt(request.getParameter("quantita").trim()));
		prodotto.setPrezzo(Double.parseDouble(request.getParameter("prezzo")));
		
		Part filePart = request.getPart("foto");
		InputStream is = null;
		if(filePart != null) {
			is = filePart.getInputStream();
			if(is != null) {
				BufferedImage foto = ImageIO.read(is);
				String formato = filePart.getContentType();
				prodotto.setFormato(formato);
				String formatoParamater = prodotto.getFormato().substring(1);
				String path = prodotto.takepath();
				File image = new File(path);
				ImageIO.write(foto, formatoParamater, image);
				prodotto.setFotoPath(path);
				FileInputStream fis = new FileInputStream(image);
				prodotto.setFis(fis);
				prodotto.setLenghtImage((int)image.length());
			}
			
		}
		//Parse da String a sql.Date
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				java.sql.Date sqlDateProd = null;
				java.sql.Date sqlDateScad = null;
			    try {
			        java.util.Date utilDate = format.parse(request.getParameter("data_produzione").trim());
			        sqlDateProd = new java.sql.Date(utilDate.getTime());
			        utilDate = format.parse(request.getParameter("data_scadenza").trim());
			        sqlDateScad = new java.sql.Date(utilDate.getTime());
			    } catch (ParseException e) {
			        e.printStackTrace();
			    }
		prodotto.setData_produzione(sqlDateProd);
		prodotto.setData_scadenza(sqlDateScad);
		
		ProdottoModel model = new ProdottoModel();
		
		try {
			model.insert(prodotto);
			request.getSession().setAttribute("riuscito", true);
			request.getSession().setAttribute("codiceProdotto",  prodotto.getCodice());
			RequestDispatcher dispatcher = request.getRequestDispatcher("shop.jsp");
			dispatcher.forward(request, response);
			return;
		}
		catch (SQLException e) {
			request.getSession().setAttribute("nonriuscito", true);
			response.sendRedirect("shop.jsp");
			return;
		}
	}
}

