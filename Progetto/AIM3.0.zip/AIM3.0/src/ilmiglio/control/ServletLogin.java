package ilmiglio.control;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ilmiglio.model.ClienteBean;
import ilmiglio.model.ClienteModel;
import ilmiglio.model.UtenteBean;
import ilmiglio.model.UtenteModel;
import ilmiglio.util.Carrello;

/**
 * Servlet implementation class ServletAccesso
 */
@WebServlet("/ServletLogin")
public class ServletLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("accesso.jsp");
		return;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String email = request.getParameter("email");
		String pass = request.getParameter("pass");
		UtenteModel model = new UtenteModel();
		
		try {
			UtenteBean utente = model.doRetrieveByKey(email);
			
			if (utente == null) {
				request.getSession().setAttribute("email", "account non esiste");
				RequestDispatcher dispatcher = request.getRequestDispatcher("accesso.jsp");
				dispatcher.forward(request, response);
			}
			else if (utente.getPass().trim().equals(pass)) {
				//significa che va bene
				request.getSession().setAttribute("utente", utente);
				request.getSession().setAttribute("ruolo", utente.getTipo());
				
				if (utente.getTipo().trim().equals("cliente")) {
					ClienteModel modelCliente = new ClienteModel();
					ClienteBean clienteBean = modelCliente.doRetrieveByKey(utente.getEmail());
					request.getSession().setAttribute("cliente", clienteBean);
				
					Carrello carrello = new Carrello();
					request.getSession().setAttribute("carrello", carrello);
				}
				
				if (utente.getTipo().trim().equals("admin")) {
					response.sendRedirect("index.jsp");
					return;
				}
				if (utente.getTipo().trim().equals("adminp")) {
					response.sendRedirect("index.jsp");
					return;
				}
				response.sendRedirect("index.jsp");
				return;
			}
			else {
				//la password � errata
				request.setAttribute("email", email);
				request.setAttribute("pwErrata", true);
				RequestDispatcher dispatcher = request.getRequestDispatcher("accesso.jsp");
				dispatcher.forward(request, response);
				return;
			}
		} catch (SQLException e) {
			//non si sa cos'� successo
			//nel dubbio torna alla pagina precedente
			response.sendRedirect("accesso.jsp");
			return;
		}
	}

}
