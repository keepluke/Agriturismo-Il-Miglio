package ilmiglio.control;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import ilmiglio.model.PrenotazioneBean;
import ilmiglio.model.PrenotazioneModel;
import ilmiglio.model.UtenteBean;

@SuppressWarnings("serial")
@WebServlet("/ServletPrenotazione")
public class ServletPrenotazione extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UtenteBean utente = (UtenteBean) request.getSession().getAttribute("utente");
		String email = utente.getEmail();
		String data = request.getParameter("dataIn");
		String orario = request.getParameter("orario");
		String posti = request.getParameter("postiIn");
		String commento = request.getParameter("commentoIn");
		PrenotazioneBean prenotazione = new PrenotazioneBean();
		prenotazione.setEmail(email);
		prenotazione.setOrario(orario);;
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		java.sql.Date sqlDate = null;
	    try {
	        java.util.Date utilDate = format.parse(data);
	        sqlDate = new java.sql.Date(utilDate.getTime());
	    } catch (ParseException e) {
	        e.printStackTrace();
	    }
		prenotazione.setData(sqlDate);
		prenotazione.setPosti(Integer.parseInt(posti));
		if(commento != null) {
			prenotazione.setCommento(commento);
		}
		
		PrenotazioneModel modello = new PrenotazioneModel();
		
		try {
			int controllo = modello.controlloPosti(data, orario);
			controllo = 30 - controllo;
			if(Integer.parseInt(posti) <= controllo) {
				modello.insert(prenotazione);
				request.getSession().setAttribute("riuscita", true);
			} 
			else {
				request.getSession().setAttribute("posti_occupati", true);
			}
			
		} catch (SQLException e) {
			request.getSession().setAttribute("no", true);
		}finally {
			RequestDispatcher dispatcher = request.getRequestDispatcher("prenotazione.jsp");
			dispatcher.forward(request, response);
		}
	}
}
