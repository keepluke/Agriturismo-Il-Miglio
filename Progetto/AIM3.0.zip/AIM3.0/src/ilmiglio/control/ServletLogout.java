package ilmiglio.control;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ServletLogout
 */
@WebServlet("/ServletLogout")
public class ServletLogout extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletLogout() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		synchronized (session) {
			session.removeAttribute("ruolo");
			session.removeAttribute("utente");
			session.removeAttribute("cliente");
			session.removeAttribute("carrello");
			session.removeAttribute("riuscito");
			session.removeAttribute("codiceProdotto");
			session.removeAttribute("nonriuscito");
			session.removeAttribute("cancellato");
			session.removeAttribute("noncancellato");
			session.removeAttribute("acquistoEffettuato");
			session.removeAttribute("nonEffettuatuo");
			session.removeAttribute("email");
			session.removeAttribute("pwErrata");
			session.removeAttribute("riuscita");
			session.removeAttribute("posti_occupati");
			session.removeAttribute("no");
			session.removeAttribute("loginInvalidaReg");
			session.invalidate();
		}
		response.sendRedirect("index.jsp");
		return;	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
