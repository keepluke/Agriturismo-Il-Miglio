package ilmiglio.control;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ilmiglio.model.ProdottoBean;
import ilmiglio.model.ProdottoModel;
import ilmiglio.util.Carrello;

/**
 * Servlet implementation class ServletCarrello
 */
@WebServlet("/ServletCarrello")
public class ServletCarrello extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletCarrello() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//deve aggiugere o rimuovere a seconda dell'action
		//recupero il carrello
		//posso chiamare il metodo aggiungi o rimuovi
		//ci serve il prodotto
		//conosciamo il codice
		//usiamo il model.doRetrieveByKey
		
		String action = request.getParameter("action");
		Carrello carrello = (Carrello) request.getSession().getAttribute("carrello");
		String codProd = request.getParameter("codProd");
		
		if ((action == null) || (carrello == null) || (codProd == null)) {
			//lo rimando alla pagina carrello
			response.sendRedirect("checkout.jsp");
			return;
		}
		
		int codice = Integer.parseInt(codProd);
		
		try {
			ProdottoModel model = new ProdottoModel();
			ProdottoBean prodotto = model.doRetrieveByKey(codice);
			
			if (prodotto == null) {
				response.sendRedirect("checkout.jsp");
				return;
			}
			
			
			if (action.trim().equals("aggiungi")) {
				carrello.aggiungi(prodotto);
				
				//salvo il carrello
				request.getSession().setAttribute("carrello", carrello);
				
				//ritorno alla pagina prodotti
				RequestDispatcher dispatcher = request.getRequestDispatcher("checkout.jsp");
				dispatcher.forward(request, response);
				return;
			}
			else if (action.trim().equals("rimuovi")) {
				carrello.rimuovi(prodotto);
				
				//salvo il carrello
				request.getSession().setAttribute("carrello", carrello);
				
				//ritorno alla pagina carrello
				RequestDispatcher dispatcher = request.getRequestDispatcher("checkout.jsp");
				dispatcher.forward(request, response);
				return;
			}
			else {
				//errore
				response.sendRedirect("checkout.jsp");
				return;
			}
		}
		catch (SQLException e) {
			response.sendRedirect("checkout.jsp");
			return;
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
