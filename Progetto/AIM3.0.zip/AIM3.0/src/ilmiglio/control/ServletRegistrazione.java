package ilmiglio.control;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ilmiglio.model.ClienteBean;
import ilmiglio.model.ClienteModel;

import ilmiglio.model.UtenteBean;
import ilmiglio.model.UtenteModel;
import ilmiglio.util.Carrello;


/**
 * Servlet implementation class ServletRegistrazione
 */
@WebServlet("/ServletRegistrazione")
public class ServletRegistrazione extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletRegistrazione() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//andiamo a prendere i dati
		String nome = request.getParameter("nome");
		String cognome = request.getParameter("cognome");
		String telefono = request.getParameter("telefono");
		String indirizzo = request.getParameter("indirizzo");
		String email = request.getParameter("email");
		String pass = request.getParameter("pass");
		
		//procedo solo se hai inserito una login valida
		//se gi� esiste un altro utente con la tua stessa login, non va bene
		UtenteModel modelUtente = new UtenteModel();
		try {
			UtenteBean utente = modelUtente.doRetrieveByKey(email);
			if (utente != null) {
				//gi� c'� un altro utente che usa la tua stessa login
				//non va bene, devi sceglierne un'altra
				//ti avviso che il precedente tentativo non � riuscito
				request.getSession().setAttribute("loginInvalidaReg", true);
				//torna alla pagina di registrazione
				RequestDispatcher dispatcher = request.getRequestDispatcher("accesso.jsp");
				dispatcher.forward(request, response);
				return;
			}
			else {
				//puoi registrarti
				utente = new UtenteBean();
				utente.setEmail(email);
				utente.setPass(pass);
				utente.setTipo("cliente");
				modelUtente.insert(utente);
				GregorianCalendar cal = new GregorianCalendar();
				
				int anno = cal.get(Calendar.YEAR);
				int mese = cal.get(Calendar.MONTH) + 1;
				int giorno = cal.get(Calendar.DAY_OF_MONTH);
				String data = ""+anno+"-"+mese+"-"+giorno;
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				@SuppressWarnings("unused")
				java.sql.Date sqlDate = null;
			    try {
			        java.util.Date utilDate = format.parse(data);
			        sqlDate = new java.sql.Date(utilDate.getTime());
			    } catch (ParseException e) {
			        e.printStackTrace();
			    }
				
				//inserisco un nuovo cliente nella tabella cliente
				ClienteModel modelCliente = new ClienteModel();
				ClienteBean cliente = new ClienteBean();
				cliente.setCognome_cliente(cognome.trim());
				cliente.setNome_cliente(nome.trim());
				cliente.setEmail_cliente(email.trim());
				cliente.setTelefono(telefono.trim());
				cliente.setIndirizzo(indirizzo.trim());
				modelCliente.insert(cliente);
				
				//nella sessione dobbiamo salvare il ruolo
				//e l'utente
				Carrello carrello = new Carrello();
				request.getSession().setAttribute("carrello", carrello);
				request.getSession().setAttribute("ruolo", utente.getTipo());
				request.getSession().setAttribute("utente", utente);
				request.getSession().setAttribute("cliente", cliente);
				
				//andiamo all'area personale
				response.sendRedirect("index.jsp");
				return;
			}
		} catch (SQLException e) {
			response.sendRedirect("accesso.jsp");
			return;
		}
	}

}
