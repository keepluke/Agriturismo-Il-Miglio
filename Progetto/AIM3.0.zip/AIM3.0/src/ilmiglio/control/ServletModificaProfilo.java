package ilmiglio.control;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ilmiglio.model.ClienteBean;
import ilmiglio.model.ClienteModel;


/**
 * Servlet implementation class ServletModificaProfilo
 */
@WebServlet("/ServletModificaProfilo")
public class ServletModificaProfilo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletModificaProfilo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String indirizzo = (String) request.getParameter("indirizzo");
		String telefono = (String) request.getParameter("telefono");
		
		ClienteBean bean = (ClienteBean) request.getSession().getAttribute("cliente");
		if(indirizzo != "") {
			bean.setIndirizzo(indirizzo);
		}
		System.out.println("vuoto"+indirizzo);
		if(telefono != "") {
			bean.setTelefono(telefono);
		}
		ClienteModel model = new ClienteModel();
		try {
			model.update(bean);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		response.sendRedirect("areaPersonale.jsp");
		return;
	}
}	


