package ilmiglio.control;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ilmiglio.model.AcquistoBean;
import ilmiglio.model.AcquistoModel;

import ilmiglio.model.ESoggettoBean;
import ilmiglio.model.ESoggettoModel;
import ilmiglio.model.ProdottoBean;
import ilmiglio.model.ProdottoModel;
import ilmiglio.model.UtenteBean;
import ilmiglio.util.Carrello;
import ilmiglio.util.ProdottoInCarrello;

/**
 * Servlet implementation class ServletAcquisto
 */
@WebServlet("/ServletAcquisto")
public class ServletAcquisto extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ServletAcquisto() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 * 
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {

			GregorianCalendar cal = new GregorianCalendar();
			int anno = cal.get(Calendar.YEAR);
			int mese = cal.get(Calendar.MONTH) + 1;
			int giorno = cal.get(Calendar.DAY_OF_MONTH);
			String data = "" + anno + "-" + mese + "-" + giorno;
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			java.sql.Date sqlDate = null;
			try {
				java.util.Date utilDate = format.parse(data);
				sqlDate = new java.sql.Date(utilDate.getTime());
			} catch (ParseException e) {
				e.printStackTrace();
			}

			UtenteBean utente = (UtenteBean) request.getSession().getAttribute("utente");
			String email_utente = null;
			if (utente == null) {
				response.sendRedirect("index.jsp");
				return;
			}
			email_utente = utente.getEmail();

			// Inserisci nella tabella acquisto
			AcquistoModel modello_acquisto = new AcquistoModel();
			AcquistoBean acquisto = new AcquistoBean();
			acquisto.setData_acquisto(sqlDate);
			acquisto.setEmail_utente(email_utente);
			acquisto.setTotale(Double.parseDouble(request.getParameter("totale").trim()));
			modello_acquisto.insert(acquisto);

			// Prendi codice scontrino
			int cod_scontrino = 0;
			ArrayList<AcquistoBean> acquisti = modello_acquisto.doRetrieveByKey(sqlDate, email_utente);
			for (int i = 0; i < acquisti.size(); i++) {
				cod_scontrino = acquisti.get(i).getCodice_scontrino();
			}

			// Inserisci nella tabella �_soggetto x ogni prodotto
			ESoggettoModel esoggModel = new ESoggettoModel();
			Carrello carrello = (Carrello) request.getSession().getAttribute("carrello");
			ArrayList<ProdottoInCarrello> prodotti = carrello.getProdotti();

			for (int i = 0; i < prodotti.size(); i++) {
				ProdottoInCarrello prodInCarr = prodotti.get(i);
				ProdottoBean prodotto = prodInCarr.getProdotto();
				int codProd = prodotto.getCodice();
				int quantita = prodInCarr.getQuantita();
				ESoggettoBean esoggetto = new ESoggettoBean();
				esoggetto.setCodice_scontrino(cod_scontrino);
				esoggetto.setCodice_prodotto(codProd);
				esoggetto.setQuantita(quantita);
				esoggModel.insert(esoggetto);
				ProdottoModel model = new ProdottoModel();
				int quant = prodotto.getQuantit�_disponibile() - quantita;
				model.doUpdateQuantita(codProd, quant);
			}

			Carrello newcarrello = new Carrello();

			request.getSession().setAttribute("carrello", newcarrello);
			request.getSession().setAttribute("acquistoEffettuato", true);
			response.sendRedirect("shop.jsp");
			return;
		} catch (SQLException e) {
			request.getSession().setAttribute("nonEffettuatuo", true);
			return;
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 * 
	 *      Rimanda alla doGet
	 * 
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
