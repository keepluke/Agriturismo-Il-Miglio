package ilmiglio.control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ilmiglio.model.PrenotazioneBean;
import ilmiglio.model.PrenotazioneModel;
import ilmiglio.model.UtenteBean;

/**
 * Servlet implementation class ServletPrenotazioniEffettuateCliente
 */
@WebServlet("/ServletPrenotazioniEffettuateCliente")
public class ServletPrenotazioniEffettuateCliente extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ServletPrenotazioniEffettuateCliente() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		System.out.println("sto qui");
		PrintWriter out = response.getWriter();
		PrenotazioneModel model = new PrenotazioneModel();
		UtenteBean utente = (UtenteBean) request.getSession().getAttribute("utente");
		String email = utente.getEmail().trim();
		ArrayList<PrenotazioneBean> prenotazioni = null;
		System.out.println("" + prenotazioni);
		System.out.println(email);
		try {
			prenotazioni = (ArrayList<PrenotazioneBean>) model.doRetrieveAllByEmail(email);
			System.out.println("qui sta nel try");
		} catch (SQLException e) {
			out.print("<tr><td>Non ci sono prenotazioni<td><tr>");
			System.out.println("entra nel checc");
		}
		if (prenotazioni.isEmpty()) {
			out.println("<tr><td>Non ci sono prenotazioni.</td></tr>");
			System.out.println("qui sta nell'if");
		} else {
			for (int i = 0; i < prenotazioni.size(); i++) {
				System.out.println("qui sta nel for");
				PrenotazioneBean prenotazione = prenotazioni.get(i);
				out.println("<tr><td> <form action='ServletEliminaPrenotazione?email=" + email + "&date="
						+ prenotazione.getData()
						+ "' method='POST''><input type='submit' value='Elimina'></form> </td><td>Data: "
						+ prenotazione.getData() + "</td><td>Posti: " + prenotazione.getPosti() + "</td>"
						+ "<td>Commento: " + prenotazione.getCommento() + "</td></tr>");
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
