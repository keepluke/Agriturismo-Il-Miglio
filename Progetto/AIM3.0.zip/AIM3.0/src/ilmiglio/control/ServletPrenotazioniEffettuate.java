package ilmiglio.control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ilmiglio.model.PrenotazioneBean;
import ilmiglio.model.PrenotazioneModel;

/**
 * Servlet implementation class ServletOrdiniEffettuati
 */
@WebServlet("/ServletPrenotazioniEffettuate")
public class ServletPrenotazioniEffettuate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletPrenotazioniEffettuate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		System.out.println("sono in prenotazioni");
		PrintWriter out = response.getWriter();
		PrenotazioneModel model = new PrenotazioneModel();
		ArrayList<PrenotazioneBean> ordini = null;
		try {
			ordini = (ArrayList<PrenotazioneBean>) model.doRetrieveAll();
		} catch (SQLException e) {
			out.print("<tr><td>Non ci sono prenotazioni<td><tr>");
		}
		if(ordini == null) {
			out.println("<tr><td>Non ci sono prenotazioni.</td></tr>");
		}else {
		for(int i = 0; i < ordini.size(); i++) {
			PrenotazioneBean acquisto = ordini.get(i);
			out.println("<tr><td>Cliente: "+acquisto.getEmail()+"</td><td>Data: "+acquisto.getData()+"</td><td>Posti: "+acquisto.getPosti()+"</td></tr>");
		}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
