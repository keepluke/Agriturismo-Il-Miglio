package ilmiglio.control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ilmiglio.model.ProdottoBean;
import ilmiglio.model.ProdottoModel;


/**
 * Servlet implementation class ServletModificaProdotto
 */
@WebServlet("/ServletModificaProdotto")
public class ServletModificaProdotto extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletModificaProdotto() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int codpro = Integer.parseInt(request.getParameter("codpro"));
		String nome_tipo = (String)request.getParameter("nome_tipo");
		Double prezzo = Double.parseDouble(request.getParameter("prezzo").trim());
	    int quantita = Integer.parseInt(request.getParameter("quantita").trim());
	    PrintWriter out = response.getWriter();
	    ProdottoBean bean = new ProdottoBean();
	    bean.setCodice(codpro);
	    bean.setNome_tipo(nome_tipo);
	    bean.setPrezzo(prezzo);
	    bean.setQuantit�_disponibile(quantita);
		ProdottoModel model = new ProdottoModel();
		try {
			model.update(bean);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			response.sendRedirect("index.jsp");
			out.println("<p>Errore nella modifica</p>");
			return;
		}
		response.sendRedirect("shop.jsp");
		return;
	}
	/**
	 * 		String indirizzo = (String) request.getParameter("indirizzo");
		String telefono = (String) request.getParameter("telefono");
		
		ClienteBean bean = (ClienteBean) request.getSession().getAttribute("cliente");
		bean.setIndirizzo(indirizzo);
		bean.setTelefono(telefono);
		
		ClienteModel model = new ClienteModel();
		try {
			model.update(bean);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		response.sendRedirect("areaPersonale.jsp");
		return;
	 */

}
