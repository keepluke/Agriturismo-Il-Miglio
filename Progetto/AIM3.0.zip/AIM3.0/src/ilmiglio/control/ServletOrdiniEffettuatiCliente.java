package ilmiglio.control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ilmiglio.model.AcquistoBean;
import ilmiglio.model.AcquistoModel;
import ilmiglio.model.UtenteBean;

/**
 * Servlet implementation class ServletOrdiniEffettuatiCliente
 */
@WebServlet("/ServletOrdiniEffettuatiCliente")
public class ServletOrdiniEffettuatiCliente extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletOrdiniEffettuatiCliente() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		AcquistoModel model = new AcquistoModel();
		UtenteBean utente = (UtenteBean) request.getSession().getAttribute("utente");
		String email = utente.getEmail().trim();
		ArrayList<AcquistoBean> ordini = null;
		try {
			ordini = (ArrayList<AcquistoBean>) model.doRetrieveByEmail(email);
		} catch (SQLException e) {
			out.print("<tr><td>Non ci sono ordini<td><tr>");
		}
		if(ordini.isEmpty()) {
			out.println("<tr><td>Non ci sono ordini.</td></tr>");
		}else {
		for(int i = 0; i < ordini.size(); i++) {
			AcquistoBean ordine = ordini.get(i);
			out.println("<tr><td>Codice scontrino: "+ordine.getCodice_scontrino()+"</td><td>Data: "+ordine.getData_acquisto()+"</td>"+"<td>Totale: "+ordine.getTotale()+"</td></tr>");
		}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
