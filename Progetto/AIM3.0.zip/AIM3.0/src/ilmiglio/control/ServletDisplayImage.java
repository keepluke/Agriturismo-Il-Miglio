package ilmiglio.control;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ilmiglio.model.ProdottoModel;


/**
 * Servlet implementation class ServletDisplayImage
 */
@WebServlet("/ServletDisplayImage")
public class ServletDisplayImage extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	 
	
	 
	
	public  static InputStream inn ;
	
	 
	 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletDisplayImage() {
        super();
        // TODO Auto-generated constructor stub
       
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("pippo");

		//int cod = Integer.parseInt(request.getParameter("cod").trim());
		
		int codice_prodotto = Integer.parseInt(request.getParameter("COD"));
		
		System.out.println("codiceeeeeeeeeeeeeeeeeeeeeee: " + codice_prodotto);
		
		ProdottoModel model = new ProdottoModel();
		
		try {
			 inn = model.findImageById(codice_prodotto);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//indice = Integer.parseInt(request.getParameter("IND"));
		BufferedInputStream bin = null;
		BufferedOutputStream bout = null;
		response.setContentType("image/jpeg");
		ServletOutputStream out;
		out = response.getOutputStream();
		bin = new BufferedInputStream(inn);
		bout = new BufferedOutputStream(out);
		int ch = 0;
		while((ch=bin.read()) != -1) {
					bout.write(ch);
		}
		
		if(bin!=null)bin.close();  
		if(inn!=null)inn.close();  
		if(bout!=null)bout.close();  
		if(out!=null)out.close();
		
		 return;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

 
 
 

 
	
 
}
